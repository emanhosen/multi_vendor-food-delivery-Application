 <footer class="footer" style="text-align: center;">Online Food Delivery BD © 2024 - Online Food Ordering System Developer - </footer>
